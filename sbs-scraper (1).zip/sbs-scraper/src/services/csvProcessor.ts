import Papa from 'papaparse';
import type { VtexProduct } from './vtexApi';
import { extractSpec, getBestImageUrl, getPrice } from './vtexApi';

// ─────────────────────────────────────────────
// TIPOS
// ─────────────────────────────────────────────

// Una fila del CSV de entrada del usuario (puede venir horizontal o vertical)
export interface InputRow {
  isbn: string;        // Código de barras
  sku: string;
  nombre: string;
  precio: string;
  stock: string;
  peso: string;
  alto: string;
  ancho: string;
  profundidad: string;
  raw: Record<string, string>;
}

// 31 columnas de salida (según Settings.csv)
// "Descripción" aparece dos veces: col 15 = corta, col 31 = compuesta
// Las nombramos: "Descripción" y "Descripción Compuesta"
export interface OutputRow {
  'Identificador de URL': string;       // 1
  'Nombre': string;                     // 2  na
  'Categorías': string;                 // 3  na
  'Precio': string;                     // 4  na
  'Precio promocional': string;         // 5  na
  'Peso (kg)': string;                  // 6  defecto=0.5
  'Alto (cm)': string;                  // 7  defecto=18
  'Ancho (cm)': string;                 // 8  defecto=13
  'Profundidad (cm)': string;           // 9  defecto=1
  'Stock': string;                      // 10 na
  'SKU': string;                        // 11 input
  'Código de barras': string;           // 12 input
  'Mostrar en tienda': string;          // 13 defecto=SI
  'Envío sin cargo': string;            // 14 defecto=NO
  'Descripción': string;                // 15 rq (descripción corta de VTEX)
  'Tags': string;                       // 16 rq
  'Título para SEO': string;            // 17 rq
  'Descripción para SEO': string;       // 18 rq
  'Marca': string;                      // 19 rq
  'Producto Físico': string;            // 20 defecto=SI
  'MPN (Número de pieza del fabricante)': string; // 21 = ISBN
  'Sexo': string;                       // 22 rq = Unisex
  'Rango de edad': string;              // 23 rq
  'Costo': string;                      // 24 na
  'Autor': string;                      // 25 rq (NUEVO)
  'Pag.': string;                       // 26 rq (NUEVO)
  'EDAD': string;                       // 27 rq (NUEVO)
  'FOTO TAPA': string;                  // 28 rq (NUEVO)
  'Encuadernación': string;             // 29 rq (NUEVO)
  'Trailer/Video': string;              // 30 na (NUEVO)
  'Descripción Compuesta': string;      // 31 rq (NUEVO - la descripción armada)
  // Campos internos para la UI (no van al CSV)
  _isbn: string;
  _imageUrl: string;
  _status: 'ok' | 'error' | 'pending';
  _error?: string;
}

// Columnas exactas del CSV de salida, en orden (31 columnas)
export const OUTPUT_COLUMNS: (keyof Omit<OutputRow, '_isbn' | '_imageUrl' | '_status' | '_error'>)[] = [
  'Identificador de URL',
  'Nombre',
  'Categorías',
  'Precio',
  'Precio promocional',
  'Peso (kg)',
  'Alto (cm)',
  'Ancho (cm)',
  'Profundidad (cm)',
  'Stock',
  'SKU',
  'Código de barras',
  'Mostrar en tienda',
  'Envío sin cargo',
  'Descripción',
  'Tags',
  'Título para SEO',
  'Descripción para SEO',
  'Marca',
  'Producto Físico',
  'MPN (Número de pieza del fabricante)',
  'Sexo',
  'Rango de edad',
  'Costo',
  'Autor',
  'Pag.',
  'EDAD',
  'FOTO TAPA',
  'Encuadernación',
  'Trailer/Video',
  'Descripción Compuesta',
];

// Valores por defecto (marcados como "defecto" en Settings.csv)
const DEFAULTS: Partial<OutputRow> = {
  'Peso (kg)': '0.5',
  'Alto (cm)': '18',
  'Ancho (cm)': '13',
  'Profundidad (cm)': '1',
  'Mostrar en tienda': 'SI',
  'Envío sin cargo': 'NO',
  'Producto Físico': 'SI',
  'Sexo': 'Unisex',
  'Trailer/Video': '',
};

// ─────────────────────────────────────────────
// PARSEO DEL CSV DE ENTRADA
// ─────────────────────────────────────────────

export function parseInputCSV(csvText: string): InputRow[] {
  const result = Papa.parse<string[]>(csvText, {
    skipEmptyLines: true,
    header: false,
  });

  if (!result.data || result.data.length === 0) return [];

  const firstCell = String(result.data[0]?.[0] ?? '').trim();

  // ── FORMATO VERTICAL (como el ejemplo que me pasaste) ──
  // Fila 0 = ["Identificador de URL", val1, val2, ...]
  // Fila 1 = ["Nombre", val1, val2, ...]
  // etc. → cada columna > 0 es un producto
  if (firstCell.toLowerCase().includes('identificador') || firstCell === 'Nombre') {
    return parseVerticalFormat(result.data);
  }

  // ── FORMATO HORIZONTAL (el más común para múltiples productos) ──
  // Fila 0 = headers
  // Fila 1..N = datos
  return parseHorizontalFormat(result.data);
}

function parseVerticalFormat(data: string[][]): InputRow[] {
  // Extraer nombres de campo de la columna 0
  const fieldNames = data.map(row => String(row[0] ?? '').trim());
  const numCols = Math.max(...data.map(r => r.length));
  const rows: InputRow[] = [];

  // Cada columna > 0 es un producto
  for (let col = 1; col < numCols; col++) {
    const raw: Record<string, string> = {};
    fieldNames.forEach((field, i) => {
      if (field) raw[field] = String(data[i]?.[col] ?? '').trim();
    });

    const isbn = (raw['Código de barras'] ?? '').trim();
    if (!isbn) continue;

    rows.push(rawToInputRow(raw, isbn));
  }
  return rows;
}

function parseHorizontalFormat(data: string[][]): InputRow[] {
  const headers = data[0].map(h => String(h ?? '').trim());
  const rows: InputRow[] = [];

  for (let i = 1; i < data.length; i++) {
    const raw: Record<string, string> = {};
    headers.forEach((h, idx) => {
      raw[h] = String(data[i]?.[idx] ?? '').trim();
    });

    // Buscar ISBN en varios posibles nombres de columna
    const isbn = (
      raw['Código de barras'] ??
      raw['Codigo de barras'] ??
      raw['ISBN'] ??
      raw['isbn'] ??
      raw['EAN'] ??
      ''
    ).trim();

    if (!isbn) continue;
    rows.push(rawToInputRow(raw, isbn));
  }
  return rows;
}

function rawToInputRow(raw: Record<string, string>, isbn: string): InputRow {
  return {
    isbn,
    sku: raw['SKU'] ?? '',
    nombre: raw['Nombre'] ?? '',
    precio: raw['Precio'] ?? '',
    stock: raw['Stock'] ?? '2',
    peso: raw['Peso (kg)'] || DEFAULTS['Peso (kg)']!,
    alto: raw['Alto (cm)'] || DEFAULTS['Alto (cm)']!,
    ancho: raw['Ancho (cm)'] || DEFAULTS['Ancho (cm)']!,
    profundidad: raw['Profundidad (cm)'] || DEFAULTS['Profundidad (cm)']!,
    raw,
  };
}

// Parsear lista plana de ISBNs (un ISBN por línea, separados por coma/punto y coma)
export function parseISBNList(text: string): InputRow[] {
  const isbns = text
    .split(/[\n\r,;]+/)
    .map(s => s.trim())
    .filter(s => /^\d{10,13}$/.test(s));

  return isbns.map(isbn => ({
    isbn,
    sku: '',
    nombre: '',
    precio: '',
    stock: '2',
    peso: DEFAULTS['Peso (kg)']!,
    alto: DEFAULTS['Alto (cm)']!,
    ancho: DEFAULTS['Ancho (cm)']!,
    profundidad: DEFAULTS['Profundidad (cm)']!,
    raw: { 'Código de barras': isbn },
  }));
}

// ─────────────────────────────────────────────
// CONSTRUCCIÓN DE LA FILA DE SALIDA (31 cols)
// ─────────────────────────────────────────────

export function buildOutputRow(input: InputRow, product: VtexProduct | null): OutputRow {
  if (!product) {
    return {
      'Identificador de URL': '',
      'Nombre': input.nombre || '',
      'Categorías': '',
      'Precio': input.precio || '',
      'Precio promocional': '',
      'Peso (kg)': input.peso,
      'Alto (cm)': input.alto,
      'Ancho (cm)': input.ancho,
      'Profundidad (cm)': input.profundidad,
      'Stock': input.stock,
      'SKU': input.sku,
      'Código de barras': input.isbn,
      'Mostrar en tienda': DEFAULTS['Mostrar en tienda']!,
      'Envío sin cargo': DEFAULTS['Envío sin cargo']!,
      'Descripción': '',
      'Tags': '',
      'Título para SEO': '',
      'Descripción para SEO': '',
      'Marca': '',
      'Producto Físico': DEFAULTS['Producto Físico']!,
      'MPN (Número de pieza del fabricante)': input.isbn,
      'Sexo': DEFAULTS['Sexo']!,
      'Rango de edad': '',
      'Costo': '',
      'Autor': '',
      'Pag.': '',
      'EDAD': '',
      'FOTO TAPA': '',
      'Encuadernación': '',
      'Trailer/Video': '',
      'Descripción Compuesta': '',
      _isbn: input.isbn,
      _imageUrl: '',
      _status: 'error',
      _error: 'Producto no encontrado en SBS',
    };
  }

  // Extraer specs desde VTEX
  const nombre     = product.productName ?? input.nombre;
  const autor      = extractSpec(product, 'Autor') || extractSpec(product, 'autor') || '';
  const paginas    = extractSpec(product, 'Paginas') || extractSpec(product, 'Pag.') || extractSpec(product, 'pag') || extractSpec(product, 'Páginas') || '';
  const edad       = extractSpec(product, 'Edad') || extractSpec(product, 'EDAD') || extractSpec(product, 'Rango de edad') || '';
  const encuad     = extractSpec(product, 'Encuadernacion') || extractSpec(product, 'Encuadernación') || extractSpec(product, 'Formato') || 'Tapa rústica';
  const categoria  = leafCategory(product);
  const tags       = buildTags(product);
  const imageUrl   = getBestImageUrl(product);
  const precio     = getPrice(product);
  const precioStr  = precio > 0 ? precio.toFixed(2) : input.precio;
  const descCorta  = product.description ?? '';
  const descComp   = buildDescripcionCompuesta(nombre, descCorta, autor, paginas, edad, product.brand ?? '', input.isbn, encuad);
  const seoTitle   = `#${nombre}`;
  const seoDesc    = `${seoTitle}${tags}${categoria}`;

  return {
    'Identificador de URL': '',
    'Nombre': `#${nombre}`,
    'Categorías': categoria || 'Adultos',
    'Precio': precioStr,
    'Precio promocional': '',
    'Peso (kg)': input.peso,
    'Alto (cm)': input.alto,
    'Ancho (cm)': input.ancho,
    'Profundidad (cm)': input.profundidad,
    'Stock': input.stock,
    'SKU': input.sku || product.items?.[0]?.itemId || '',
    'Código de barras': input.isbn,
    'Mostrar en tienda': DEFAULTS['Mostrar en tienda']!,
    'Envío sin cargo': DEFAULTS['Envío sin cargo']!,
    'Descripción': descCorta,
    'Tags': tags,
    'Título para SEO': seoTitle,
    'Descripción para SEO': seoDesc,
    'Marca': product.brand ?? '',
    'Producto Físico': DEFAULTS['Producto Físico']!,
    'MPN (Número de pieza del fabricante)': input.isbn,
    'Sexo': DEFAULTS['Sexo']!,
    'Rango de edad': edad || 'Adultos',
    'Costo': '',
    'Autor': autor,
    'Pag.': paginas,
    'EDAD': edad || 'Adultos',
    'FOTO TAPA': imageUrl,
    'Encuadernación': encuad,
    'Trailer/Video': '',
    'Descripción Compuesta': descComp,
    _isbn: input.isbn,
    _imageUrl: imageUrl,
    _status: 'ok',
  };
}

// ─────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────

function leafCategory(product: VtexProduct): string {
  const cats = product.categories ?? [];
  if (!cats.length) return '';
  // VTEX devuelve paths como "/Ficcion y temas afines/Adultos/"
  const last = cats[cats.length - 1] ?? '';
  const parts = last.split('/').filter(Boolean);
  return parts[parts.length - 1] ?? '';
}

function buildTags(product: VtexProduct): string {
  const cat = leafCategory(product).toUpperCase();
  return cat ? `LIBRO ${cat}` : 'LIBRO';
}

// Arma la descripción compuesta según el patrón exacto de Settings.csv
function buildDescripcionCompuesta(
  nombre: string,
  desc: string,
  autor: string,
  paginas: string,
  edad: string,
  editorial: string,
  isbn: string,
  encuad: string,
): string {
  const descLimpia = stripHtml(desc).trim();
  let out = `#${nombre}  <br>  <br>  DESCRIPCION  <br><br>${descLimpia}`;
  if (autor)     out += `  <br><br>AUTOR/A ${autor}`;
  if (paginas)   out += `  <br><br>CANTIDAD DE PAGINAS ${paginas}`;
  if (edad)      out += `  <br>  <br>EDAD SUGERIDA ${edad}`;
  if (editorial) out += `  <br><br>EDITORIAL ${editorial}`;
  out +=          `  <br><br>ISBN ${isbn}`;
  if (encuad)    out += `  <br><br>FICHA TECNICA: ${encuad}`;
  return out;
}

function stripHtml(html: string): string {
  return html.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
}

// ─────────────────────────────────────────────
// EXPORT CSV — FORMATO HORIZONTAL
// header en fila 1, datos en filas 2..N
// ─────────────────────────────────────────────

export function rowsToCsv(rows: OutputRow[]): string {
  const data = rows.map(row => {
    const obj: Record<string, string> = {};
    OUTPUT_COLUMNS.forEach(col => {
      obj[col] = row[col] ?? '';
    });
    return obj;
  });
  return Papa.unparse(data, { columns: OUTPUT_COLUMNS as string[] });
}
